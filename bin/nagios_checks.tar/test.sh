#!/bin/sh
# NRPE Plugin Alberto Aliaga 05/07/2004

echo "$1,$2,$3"
exit 1
 
